#show figure: set block(breakable: false)
#figure( // start preamble figure
  
  kind: "tinytable",
  supplement: "Table", // end preamble figure

block[ // start block

  #let style-dict = (
    // tinytable style-dict after
    "0_0": 0, "0_1": 0, "0_2": 0, "0_3": 0, "0_4": 0, "0_5": 0, "0_6": 0, "0_7": 0, "0_8": 0, "0_9": 0
  )

  #let style-array = ( 
    // tinytable cell style after
    (align: center,),
  )

  // Helper function to get cell style
  #let get-style(x, y) = {
    let key = str(y) + "_" + str(x)
    if key in style-dict { style-array.at(style-dict.at(key)) } else { none }
  }

  // tinytable align-default-array before
  #let align-default-array = ( left, left, left, left, left, left, left, left, left, left, ) // tinytable align-default-array here
  #show table.cell: it => {
    if style-array.len() == 0 { return it }
    
    let style = get-style(it.x, it.y)
    if style == none { return it }
    
    let tmp = it
    if ("fontsize" in style) { tmp = text(size: style.fontsize, tmp) }
    if ("color" in style) { tmp = text(fill: style.color, tmp) }
    if ("indent" in style) { tmp = pad(left: style.indent, tmp) }
    if ("underline" in style) { tmp = underline(tmp) }
    if ("italic" in style) { tmp = emph(tmp) }
    if ("bold" in style) { tmp = strong(tmp) }
    if ("mono" in style) { tmp = math.mono(tmp) }
    if ("strikeout" in style) { tmp = strike(tmp) }
    if ("smallcaps" in style) { tmp = smallcaps(tmp) }
    tmp
  }

  // tinytable align-figure before

  #table( // tinytable table start
    column-gutter: 5pt,
    columns: (auto, auto, auto, auto, auto, auto, auto, auto, auto, auto),
    stroke: none,
    rows: auto,
    align: (x, y) => {
      let style = get-style(x, y)
      if style != none and "align" in style { style.align } else { left }
    },
    fill: (x, y) => {
      let style = get-style(x, y)
      if style != none and "background" in style { style.background }
    },
 table.hline(y: 1, start: 2, end: 4, stroke: 0.03em + black), table.hline(y: 1, start: 4, end: 6, stroke: 0.03em + black), table.hline(y: 1, start: 4, end: 6, stroke: 0.03em + black),
 table.hline(y: 2, start: 0, end: 10, stroke: 0.05em + black),
 table.hline(y: 8, start: 0, end: 10, stroke: 0.08em + black),
 table.hline(y: 0, start: 0, end: 10, stroke: 0.08em + black),
    // tinytable lines before

    // tinytable header start
    table.header(
      repeat: true,
[ ], [ ], table.cell(colspan: 2, align: center)[AAA], table.cell(colspan: 2, align: center)[BBB], [ ], [ ], [ ], [ ],
[B], [C], [D], [E], [F], [G], [H], [Total], [X], [Y],
    ),
    // tinytable header end

    // tinytable cell content after
[6], [160], [110], [3.90], [2.620], [16.46], [0], [1], [4], [4],
[6], [160], [110], [3.90], [2.875], [17.02], [0], [1], [4], [4],
table.cell(colspan: 10)[grp],
[4], [108], [93], [3.85], [2.320], [18.61], [1], [1], [4], [1],
[6], [258], [110], [3.08], [3.215], [19.44], [1], [0], [3], [1],
[8], [360], [175], [3.15], [3.440], [17.02], [0], [0], [3], [2],

    // tinytable footer after

  ) // end table

  // tinytable align-figure after

] // end block
) // end figure 
